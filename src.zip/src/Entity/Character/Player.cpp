#include "Player.hpp"

namespace Entity
{
	Player::Player(Character &&character)
		: Character(character)
	{
	}
}
