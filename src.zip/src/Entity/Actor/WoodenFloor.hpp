#pragma once

#include "Actor.hpp"

namespace Entity
{
	class WoodenFloor : public Actor
	{
	public:
		WoodenFloor(Actor &&actor);
	};
}
